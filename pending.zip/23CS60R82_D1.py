# T1. Preprocessing and obtaining sentences using NLTK:

# Import Statements 
from collections import defaultdict, Counter
import string
import nltk 
import math
import numpy as np
import networkx as nx
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from numpy.linalg import norm

nltk.download('wordnet')
# Read the file :

from fileinput import filename


filename = 'input.txt'

with open(filename, 'r', encoding='UTF-8') as file:
    lines = [line.rstrip() for line in file]


# Print the lines :
i = 0
for line in lines: 
    print(f"Lines[{i}] = {line}")
    i = i + 1


# remove Punctuation :

translator = str.maketrans('', '', string.punctuation)
for i in range(0, len(lines)): 
    lines[i] = lines[i].translate(translator)


# Convert To LowerCase:
for i in range(0, len(lines)): 
    lines[i] = lines[i].lower()

# Tokenize the sentence into Words 
for i in range(0, len(lines)): 
    lines[i] = word_tokenize(lines[i])


# Remove Stopwords 
stop_words = set(stopwords.words('english'))
for i in range(0, len(lines)): 
    lines[i] = [word for word in lines[i] if word not in stop_words]


# Lemmatize, that is, reduce the different inflectional variants of a word to the dictionary form
# of the word (use WordNetLemmatizer)
wnl = WordNetLemmatizer()
for i in range(0, len(lines)): 
    lines[i] = [wnl.lemmatize(word, pos="v") for word in lines[i] if word not in stop_words]


# T2. Sentence Representation:

# First Calculate the TF : 
def tfidf(sentence, word, sentences):
    # Compute TF(w,s)
    tf = sentence.count(word)
    
    # Compute IDF(w)
    num_sentences_with_word = sum(1 for s in sentences if word in s)
    total_sentences = len(sentences)
    idf = math.log(total_sentences / (1 + num_sentences_with_word))
    
    # Compute TF-IDF
    tfidf = tf * idf
    return tfidf

words_set = set()
for sentence in lines:
    words_set.update(sentence)
vocabulary = sorted(list(words_set))

# Compute TF-IDF matrix
tf_idf = np.zeros((len(vocabulary), len(lines)))

# Calculate TF-IDF values for each word-sentence pair
for i, sentence in enumerate(lines):
    for j, word in enumerate(vocabulary):
        tf_idf[j, i] = tfidf(sentence, word, lines)





# T3. Summarization — Using PageRank
G = nx.complete_graph(len(lines))
tf_idf_transposed = np.transpose(tf_idf)

for i in range(len(tf_idf_transposed)):
    for j in range(len(tf_idf_transposed)):
        if i != j:
            A = tf_idf_transposed[i]
            B = tf_idf_transposed[j]
            norm_A = np.linalg.norm(A)
            norm_B = np.linalg.norm(B)
            
            # Handling potential division by zero 
            if norm_A > 0 and norm_B > 0:
                cosine = np.dot(A, B) / (norm_A * norm_B)
                G[i][j]['weight'] = cosine
            else:
                G[i][j]['weight'] = 0.0

# Calculate PageRank
pgr = nx.pagerank(G, alpha=0.85)

# Get indices of sentences sorted by PageRank
sorted_indices = sorted(pgr, key=pgr.get, reverse=True)

# Display the top-n sentences in the original order
top_n = 10
summary_indices = sorted_indices[:top_n]

# Write the summary sentences to the output file
with open('Summary_PR.txt', 'w', encoding='utf-8') as output_file:
    for idx in summary_indices:
        summary_sentence = ' '.join(lines[idx])  # Convert list of words to a sentence
        output_file.write(summary_sentence + '\n')


# MMR
def calculate_cosine_similarity(vector1, vector2):
    dot_product = np.dot(vector1, vector2)
    norm1 = np.linalg.norm(vector1)
    norm2 = np.linalg.norm(vector2)
    
    similarity = dot_product / (norm1 * norm2)
    
    return similarity

# Step 2: Initialize set R with the sentence that has the highest PageRank score
highest_pgr_index = np.argmax(pgr)
R = {highest_pgr_index}


lambda_param = 0.7  # Adjust the lambda parameter as needed for diversity vs. importance trade-off
top_n = 10  # Set the number of sentences to include in the summary

for _ in range(top_n - 1):  # We have already included one sentence
    max_mmr_score = -1
    selected_sentence_idx = -1

    for i in range(len(pgr)):
        if i not in R:  # Ensure the sentence is not already in set R
            mmr_score = lambda_param * pgr[i] - (1 - lambda_param) * max([calculate_cosine_similarity(tf_idf_transposed[i], tf_idf_transposed[j]) for j in R])
            
            if mmr_score > max_mmr_score:
                max_mmr_score = mmr_score
                selected_sentence_idx = i
    
    if selected_sentence_idx != -1:
        R.add(selected_sentence_idx)

# Step 4: Print the sentences in set R as the summary
with open('Summary_MMR.txt', 'w', encoding='utf-8') as output_file:
    for idx in R:
        summary_sentence = ' '.join(lines[idx])  # Convert list of words to a sentence
        output_file.write(summary_sentence + '\n')




# T1. Preprocessing and obtaining sentences using NLTK:

# Import Statements 
from collections import defaultdict, Counter
import string
import nltk 
import math
import numpy as np
import networkx as nx
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from numpy.linalg import norm
import random

nltk.download('wordnet')
# Read the file :

from fileinput import filename


filename = 'input.txt'

with open(filename, 'r', encoding='UTF-8') as file:
    lines = [line.rstrip() for line in file]


# Print the lines :
i = 0
for line in lines: 
    print(f"Lines[{i}] = {line}")
    i = i + 1


# remove Punctuation :

translator = str.maketrans('', '', string.punctuation)
for i in range(0, len(lines)): 
    lines[i] = lines[i].translate(translator)


# Convert To LowerCase:
for i in range(0, len(lines)): 
    lines[i] = lines[i].lower()

# Tokenize the sentence into Words 
for i in range(0, len(lines)): 
    lines[i] = word_tokenize(lines[i])


# Remove Stopwords 
stop_words = set(stopwords.words('english'))
for i in range(0, len(lines)): 
    lines[i] = [word for word in lines[i] if word not in stop_words]


# Lemmatize, that is, reduce the different inflectional variants of a word to the dictionary form
# of the word (use WordNetLemmatizer)
wnl = WordNetLemmatizer()
for i in range(0, len(lines)): 
    lines[i] = [wnl.lemmatize(word, pos="v") for word in lines[i] if word not in stop_words]


# T2. Sentence Representation:

# First Calculate the TF : 
def tfidf(sentence, word, sentences):
    # Compute TF(w,s)
    tf = sentence.count(word)
    
    # Compute IDF(w)
    num_sentences_with_word = sum(1 for s in sentences if word in s)
    total_sentences = len(sentences)
    idf = math.log(total_sentences / (1 + num_sentences_with_word))
    
    # Compute TF-IDF
    tfidf = tf * idf
    return tfidf

words_set = set()
for sentence in lines:
    words_set.update(sentence)
vocabulary = sorted(list(words_set))

# Compute TF-IDF matrix
tf_idf = np.zeros((len(vocabulary), len(lines)))

# Calculate TF-IDF values for each word-sentence pair
for i, sentence in enumerate(lines):
    for j, word in enumerate(vocabulary):
        tf_idf[j, i] = tfidf(sentence, word, lines)





# T3. Summarization — Using PageRank
G = nx.complete_graph(len(lines))
tf_idf_transposed = np.transpose(tf_idf)

for i in range(len(tf_idf_transposed)):
    for j in range(len(tf_idf_transposed)):
        if i != j:
            A = tf_idf_transposed[i]
            B = tf_idf_transposed[j]
            norm_A = np.linalg.norm(A)
            norm_B = np.linalg.norm(B)
            
            # Handling potential division by zero 
            if norm_A > 0 and norm_B > 0:
                cosine = np.dot(A, B) / (norm_A * norm_B)
                G[i][j]['weight'] = cosine
            else:
                G[i][j]['weight'] = 0.0

# Calculate PageRank
pgr = nx.pagerank(G, alpha=0.85)

# Get indices of sentences sorted by PageRank
sorted_indices = sorted(pgr, key=pgr.get, reverse=True)

# Display the top-n sentences in the original order
top_n = 10
summary_indices = sorted_indices[:top_n]

# Write the summary sentences to the output file
with open('Summary_PR.txt', 'w', encoding='utf-8') as output_file:
    for idx in summary_indices:
        summary_sentence = ' '.join(lines[idx])  # Convert list of words to a sentence
        output_file.write(summary_sentence + '\n')





#########################################################################################3
# Clustering Algorithm 



# Step 1: Choose the number of clusters (K)
num_sentences = len(tf_idf_transposed)
K = 5
if K>num_sentences:
    K = num_sentences

# Initialize centroids randomly
random.seed(0)  # Set a random seed for reproducibility
centroids = tf_idf[:, random.sample(range(tf_idf.shape[1]), K)]

# Initialize cluster assignments
cluster_assignment = np.zeros(tf_idf.shape[1])

# Define a maximum number of iterations
max_iterations = 300

for iteration in range(max_iterations):
    # Step 1: Assign each sentence to the nearest centroid based on cosine similarity
    for i in range(tf_idf.shape[1]):
        sentence_vector = tf_idf[:, i]
        # Calculate cosine similarity with each centroid
        similarities = [np.dot(sentence_vector, centroid) / (np.linalg.norm(sentence_vector) * np.linalg.norm(centroid)) for centroid in centroids.T]
        cluster_assignment[i] = np.argmax(similarities)
        print(cluster_assignment[i])

    # Step 2: Update centroids as the mean of points in each cluster
    new_centroids = np.zeros((tf_idf.shape[0], K))
    for cluster in range(K):
        cluster_indices = np.where(cluster_assignment == cluster)[0]
        if len(cluster_indices) > 0:
            cluster_points = tf_idf[:, cluster_indices]
            new_centroids[:, cluster] = np.mean(cluster_points, axis=1)

    # Check for convergence
    if np.array_equal(centroids, new_centroids):
        break

    centroids = new_centroids


# Print the sentences in each cluster
cluster_sentences = [[] for _ in range(K)]
cluster_lists = [[] for _ in range(K)]
for sentence_idx, cluster_idx in enumerate(cluster_assignment):
    if sentence_idx < len(lines):  # Ensure the sentence index is within the range of lines
        cluster_sentences[int(cluster_idx)].append(' '.join(lines[sentence_idx]))
        cluster_lists[int(cluster_idx)].append(lines[sentence_idx])

# Print the clusters and their sentences
for cluster_idx, sentences in enumerate(cluster_sentences):
    print(f"Cluster {cluster_idx}:")
    for sentence in sentences:
        print(f"- {sentence}")

# Now, cluster_assignment contains the cluster assignments for each sentence
# You can process the clusters as needed



####################################################################################################################
# Task 2 

summary_sentences = []

# # Define a maximum number of bigrams in common required for S2
min_common_bigrams = 2
visited_clusters = []

for cluster_idx, cluster_sentences in enumerate(cluster_lists):
    # Step a: Identify the sentence closest to the cluster centroid
    if len(cluster_sentences) == 0: 
        continue
    centroid_idx = int(cluster_assignment[cluster_idx])
    print(f"CINDEX: :  :  {cluster_idx}   {int(cluster_assignment[cluster_idx])}")
    if centroid_idx in visited_clusters: 
        continue
    visited_clusters.append(centroid_idx)
    if centroid_idx >= len(lines):
        continue  # Skip if centroid index is out of range

    centroid_sentence = lines[centroid_idx]

    # Step b: Find a sentence in the cluster with at least 3 bigrams in common with S1 (centroid_sentence)
    S2 = None
    for sentence in cluster_sentences:
        # print(f"########    {sentence}")
        if sentence == centroid_sentence:
            continue
        bigrams_S1 = set(zip(centroid_sentence, centroid_sentence[1:]))
        bigrams_sentence = set(zip(sentence, sentence[1:]))
        common_bigrams = bigrams_S1.intersection(bigrams_sentence)
        if len(common_bigrams) >= min_common_bigrams:
            S2 = sentence
            break

    # Step c: If no S2 exists, save only S1 and continue
    if S2 is None:
        summary_sentences.append(centroid_sentence)
        continue
    # Step d: Construct sentence graph G using S1 and S2
    G = nx.DiGraph()
    start_node = 'start'
    end_node = 'end'

    # Add start and end nodes
    G.add_node(start_node)
    G.add_node(end_node)

    def add_bigram_nodes(bigrams, start_node, end_node):
        prev_node = start_node
        for bigram in bigrams:
            G.add_node(bigram)
            G.add_edge(prev_node, bigram)
            prev_node = bigram
        G.add_edge(prev_node, end_node)

    add_bigram_nodes(zip([start_node] + centroid_sentence + [end_node]), start_node, end_node)
    add_bigram_nodes(zip([start_node] + S2 + [end_node]), start_node, end_node)

    # Generate a sentence by traversing from start to end node through a random path
    sentence_paths = list(nx.all_simple_paths(G, source=start_node, target=end_node))
    if sentence_paths:
        longest_path = max(sentence_paths, key=len)
        new_sentence = ' '.join([str(item[0]) for item in longest_path[1:-1] if str(item[0]) != start_node and str(item[0]) != end_node])  # Exclude start and end nodes
    else:
        new_sentence = ''  # Handle the case where no path exists

    summary_sentences.append(new_sentence)


# Print the summary sentences
for idx, sentence in enumerate(summary_sentences):
    print(f"Summary Sentence {idx + 1}: {sentence}")

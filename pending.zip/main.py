# T1. Preprocessing and obtaining sentences using NLTK:

# Import Statements 
from collections import defaultdict, Counter
import string
import nltk 
import math
import numpy as np
import networkx as nx
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from numpy.linalg import norm

nltk.download('wordnet')
# Read the file :

from fileinput import filename


filename = 'document.txt'

with open(filename, 'r', encoding='UTF-8') as file:
    lines = [line.rstrip() for line in file]


# Print the lines :
i = 0
for line in lines: 
    print(f"Lines[{i}] = {line}")
    i = i + 1


# remove Punctuation :

translator = str.maketrans('', '', string.punctuation)
for i in range(0, len(lines)): 
    lines[i] = lines[i].translate(translator)


# Convert To LowerCase:
for i in range(0, len(lines)): 
    lines[i] = lines[i].lower()

# Tokenize the sentence into Words 
for i in range(0, len(lines)): 
    lines[i] = word_tokenize(lines[i])


# Remove Stopwords 
stop_words = set(stopwords.words('english'))
for i in range(0, len(lines)): 
    lines[i] = [word for word in lines[i] if word not in stop_words]


# Lemmatize, that is, reduce the different inflectional variants of a word to the dictionary form
# of the word (use WordNetLemmatizer)
wnl = WordNetLemmatizer()
for i in range(0, len(lines)): 
    lines[i] = [wnl.lemmatize(word, pos="v") for word in lines[i] if word not in stop_words]


# T2. Sentence Representation:
# 1. Compute TF-IDF of each word w in a given sentence s.
    # a. TF(w,s) = Number of times the word w occurs in the given sentence s.
    # b. IDF(w) = log(Total number of sentences/Number of sentences with w in it).
    # c. TF-IDF of the word w in s is TF(w,s)×IDF(w).






# First Calculate the TF : 
idf_dict = defaultdict(int)
for i in range (0, len(lines)): 
    for j in set(lines[i]):
        idf_dict[j] = 1 + idf_dict[j]
    
all_items = set()
for i in range(0, len(lines)): 
    for j in range(0, len(lines[i])):
        all_items.add(lines[i][j])

for i in range(0, len(lines)): 
    counter1 = Counter(lines[i])
    lines[i] = [counter1[k] for k in all_items]
    print(lines[i])



tf_idf = [[0 for x in range(0, len(lines[y]))] for y in range(0, len(lines))] 

# Now, calculate the idf : 
num_of_sentences = len(lines)
for i in range (0, len(lines)): 
    for j in range(0, len(lines[i])):
        if idf_dict[lines[i][j]]!=0:
            tf_idf[i][j] = math.log(num_of_sentences/(1+ idf_dict[lines[i][j]]))
        else:
            tf_idf[i][j] = 0
    # print(tf_idf[i])

# T3. Summarization — Using PageRank
G = nx.complete_graph(len(lines))

for i in range(0, len(lines)): 
    for j in range(0, len(lines)):
        if i!=j:
            A = tf_idf[i]
            B = tf_idf[j]
            cosine = np.dot(A,B)/(norm(A, axis=1)*norm(B))
            G[i][j]['weight'] = cosine

# pr = nx.pagerank(G)
# sorted_nodes = sorted([(node, pagerank) for node, pagerank in pr.items()], key=lambda x:pr[x[0]])
# print(sorted_nodes)
